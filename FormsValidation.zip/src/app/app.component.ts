import { Component } from "@angular/core";
import { FormControl, FormGroup, Validators } from "@angular/forms";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  testFormGroup: FormGroup;

  testFieldAModel: string = '';
  duplicateName: boolean = false;

  testFieldBModel: string = '';
  testFieldCModel: string = '';

  
  testFormGroup2: FormGroup;

  testFieldA1Model: string = '';
  duplicateName1: boolean = false;

  testFieldB1Model: string = '';
  testFieldC1Model: string = '';

  constructor() {
    this.testFormGroup = new FormGroup({
      'testFieldAInput': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
      'testFieldBInput': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
      'testFieldCInput': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
    });
    
    this.testFormGroup2 = new FormGroup({
      'testFieldA1Input': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
      'testFieldB1Input': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
      'testFieldC1Input': new FormControl('', {
        validators: [
          Validators.required,
          Validators.maxLength(64),
          Validators.pattern('[a-zA-Z]+')
        ]
      }),
    });
  }
}