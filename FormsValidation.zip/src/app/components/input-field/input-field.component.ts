import { Component, ContentChild, OnInit } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { ERROR_MESSAGES } from 'src/app/constants/ERROR_MESSAGES.config';
import { InputDirective } from 'src/app/core/directives/input.directive';

@Component({
  selector: 'app-input-field',
  templateUrl: './input-field.component.html',
  styleUrls: ['./input-field.component.css']
})
export class InputFieldComponent implements OnInit {

  @ContentChild(InputDirective, { static: true }) appInput!: InputDirective;

  constructor(private translateService: TranslateService) {}

  get errorMessage(): { key: string, options: any } | null {
    const errors = Object.entries(this.appInput?.ngControl?.control?.errors || {});
    //console.log(this.appInput.ngControl.name, 'errors', errors);

    if (!errors.length) {
      return null;
    }

    //(testFormGroup.controls.testFieldBInput.dirty && testFormGroup.controls.testFieldBInput.touched)
    //console.log(this.appInput.ngControl.control);
    if (this.appInput.ngControl.control?.touched) {
      const [key, value] = errors[0];
      return {
        // key: ERROR_MESSAGES[key],
        key: `tester.validations.${this.appInput.ngControl.name}.${key}`,
        options: value
      };
    }

    return null;
  }

  ngOnInit(): void {
    if (!this.appInput) {
      throw new Error('InputDirective is required!');
    }
  }
}
