import { AfterContentInit, ChangeDetectorRef, Component, ContentChildren, Input, QueryList } from '@angular/core';
import { FormFieldEmptyContainerDirective } from 'src/app/core/directives/form-field-empty-container.directive';

@Component({
  selector: '[validationContext]',
  template: '<ng-content></ng-content>'
})
export class ValidationContextComponent implements AfterContentInit {
  
  //@ContentChildren(FormFieldContainerComponent, {descendants: true}) fieldValidators: QueryList<FormFieldContainerComponent>;
  //@ContentChildren(FormArrayContainerComponent, {descendants: true}) arrayValidators: QueryList<FormArrayContainerComponent>;
  @ContentChildren(FormFieldEmptyContainerDirective, {descendants: true}) directives: QueryList<FormFieldEmptyContainerDirective>;

  @Input() validationContext: string = '';
  @Input() innerValidationError: boolean = false;

  constructor(private cdRef: ChangeDetectorRef) {
    this.directives = new QueryList<FormFieldEmptyContainerDirective>;
  }

  ngAfterContentInit(): void {
    // if (this.fieldValidators) {
    //   this.fieldValidators.forEach(i => {
    //     i.setValidationContext(this.validationContext);
    //     i.setInnerValidation(this.innerValidationError);
    //   });
    // }

    // if (this.arrayValidators) {
    //   this.arrayValidators.forEach(i => {
    //     i.setValidationContext(this.validationContext);
    //     i.setInnerValidation(this.innerValidationError);
    //   });
    // }

    if (this.directives) {
      this.directives.forEach(i => {
        i.setValidationContext(this.validationContext);
        i.setInnerValidation(this.innerValidationError);
      });
    }
  }

  public clear(): void {
    // if (this.fieldValidators) {
    //   this.fieldValidators.forEach(v => {
    //     v.clear();
    //   });
    // }

    // if (this.arrayValidators) {
    //   this.arrayValidators.forEach(v => {
    //     v.clear();
    //   });
    // }

    if (this.directives) {
      this.directives.forEach(v => {
        v.clear();
      });
    }

    this.cdRef.markForCheck();
  }

}