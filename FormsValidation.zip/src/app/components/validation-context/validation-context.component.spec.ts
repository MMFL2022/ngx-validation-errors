import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidationContextComponent } from './validation-context.component';

describe('ValidationContextComponent', () => {
  let component: ValidationContextComponent;
  let fixture: ComponentFixture<ValidationContextComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ValidationContextComponent]
    });
    fixture = TestBed.createComponent(ValidationContextComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
