import { Directive, DoCheck, ElementRef, Input, Optional, Self, TemplateRef, ViewContainerRef } from '@angular/core';
import { AbstractControl, ControlContainer, FormControl, FormGroupDirective, NgControl } from '@angular/forms';

export class ForFieldErrorsContext {
  constructor(public errors: string[]) {
  }
}

@Directive({
  selector: '[appInputFormField]',
  // providers: [
  //   {
  //     provide: ControlContainer,
  //     useExisting: FormGroupDirective
  //   }
  // ]
})
export class InputFormFieldDirective implements DoCheck {

  @Input() formControlRef: AbstractControl | null = null;
  
  public errorMessages: string[] = [];

  private context = {errors: [] as string[]};

  // constructor(private viewContainer: ViewContainerRef, private template: TemplateRef<ForFieldErrorsContext>) {
  constructor(private viewContainer: ViewContainerRef) {
    //console.log('InputFormField', this.formControlRef, viewContainer);

    // let nodes = viewContainer.createEmbeddedView(template, this.context);
    // let rootElement = nodes.rootNodes[0];

    // console.log('nodes and root', nodes, rootElement);
    // this.formControlRef = ngControl;
  }

  ngDoCheck(): void {
    //console.log('ngDoCheck', this.formControlRef);

    if (this.formControlRef != null) {
      if (!this.formControlRef.valid && this.formControlRef.touched) {
        let errors = this.formControlRef.errors;
        
        if (errors != undefined) {
          //console.log('ngDoCheck formControlRef errors', errors);
          // let messages = Object.keys(this.formControlRef.errors || {}).map(error => {
          //   const fieldName = this.formControlRef?.name;
          //   const errorKey = `tester.validations.${fieldName}.${error}`;

          //   return errorKey;
          // });
          // console.log('ngDoCheck formControlRef error messages', messages);
          // this.errorMessages = messages;
        }
      }
    }
  }
}
