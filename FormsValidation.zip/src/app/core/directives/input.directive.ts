import { Directive, DoCheck, Input, Optional, Self } from '@angular/core';
import { AbstractControl, FormControl, NgControl } from '@angular/forms';

@Directive({
  selector: 'input[appInput]'
})
export class InputDirective implements DoCheck {

  @Input('input[appInput]') formControlRef: NgControl | null = null;
  
  public errorMessages: string[] = [];

  constructor(@Optional() @Self() public ngControl: NgControl) {
    //console.log('ngControl', ngControl, this.formControlRef);
    this.formControlRef = ngControl;
  }

  ngDoCheck(): void {
    //console.log('formControlRef', this.formControlRef);

    if (this.formControlRef != null) {
      if (!this.formControlRef.valid && this.formControlRef.touched) {
        let errors = this.formControlRef.errors;
        
        if (errors != undefined) {
          //console.log('ngDoCheck formControlRef errors', errors);
          let messages = Object.keys(this.formControlRef.errors || {}).map(error => {
            const fieldName = this.formControlRef?.name;
            const errorKey = `tester.validations.${fieldName}.${error}`;

            return errorKey;
          });
          //console.log('ngDoCheck formControlRef error messages', messages);
          this.errorMessages = messages;
    //       const [key, value] = errors[0];
  
    //       this.errorMessages = errors[0];
    //       console.log('this.errorMessages =', this.errorMessages);
        }
  
    //     // const [key, value] = errors[0];
    //     // return {
    //     //   // key: ERROR_MESSAGES[key],
    //     //   key: `tester.validations.${this.appInput.ngControl.name}.${key}`,
    //     //   options: value
    //     // };
      }
    }
    
  }
}
