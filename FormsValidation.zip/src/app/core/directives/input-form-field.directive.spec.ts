import { InputFormFieldDirective } from './input-form-field.directive';

describe('InputFormFieldDirective', () => {
  it('should create an instance', () => {
    const directive = new InputFormFieldDirective();
    expect(directive).toBeTruthy();
  });
});
