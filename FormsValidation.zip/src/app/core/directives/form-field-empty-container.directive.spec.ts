import { FormFieldEmptyContainerDirective } from './form-field-empty-container.directive';

describe('FormFieldEmptyContainerDirective', () => {
  it('should create an instance', () => {
    const directive = new FormFieldEmptyContainerDirective();
    expect(directive).toBeTruthy();
  });
});
